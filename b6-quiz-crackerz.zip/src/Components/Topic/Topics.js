import React from "react";

const Topics = () => {
    return <div>Topics</div>;
};

export default Topics;
